@echo off
start "" javaw -Dninjabrain.edition=light -jar "%~dp0Ninjabrain-Focus-1.5.2.jar"
