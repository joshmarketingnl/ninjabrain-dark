@echo off
start "" javaw -Dninjabrain.edition=dark -jar "%~dp0Ninjabrain-Focus-1.5.2.jar"
